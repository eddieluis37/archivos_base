<?php
class Posts
{

	public function greet()
	{
		echo "Hola";
	}

}