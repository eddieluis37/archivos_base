<?php
require_once('autoload.php');

//echo Config::ENVIRONMENT;
//$instConfig = new Config;

//var_dump($instConfig);
//$instMyProfile = new mx\bistro\MyProfile;
echo mx\bistro\Config::ENVIRONMENT;

