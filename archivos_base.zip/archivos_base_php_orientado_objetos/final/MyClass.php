<?php

namespace MyNamespace;

class MyClass
{

	public function greet()
	{
		echo 'Hola hola';
	}

}
