<?php
namespace at\bistro;
class Config
{
	const ENVIRONMENT = 'testing';
}