<?php
namespace mx\bistro;
class Config
{
	const ENVIRONMENT = 'production';
}