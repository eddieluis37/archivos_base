<?php
class Person
{

	public $age;
	public $name;
	public function run()
	{
		echo ' Estoy corriendo';
	}

}


