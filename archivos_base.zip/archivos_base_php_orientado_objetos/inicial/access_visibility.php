<?php
class MyProfile
{
	
	public function __construct()
	{

	}

}
