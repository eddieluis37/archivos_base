<?php

class Config
{
	const ENVIRONMENT = 'development';
}