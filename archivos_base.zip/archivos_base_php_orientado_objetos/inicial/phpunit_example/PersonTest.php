<?php
require_once('Person.php');
class StackTest extends PHPUnit_Framework_TestCase
{

    public function testPersonConstruct()
    {
        
    }

}
