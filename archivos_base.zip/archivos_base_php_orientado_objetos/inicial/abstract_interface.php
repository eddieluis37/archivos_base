<?php

class Animal
{

	public function makeSound();

	public function run()
	{

	}
}

class Dog(){}

class Cat(){}

class IDB
{
	public function connect();
}

class MySQL{}
class Oracle{}