<?php
class Person
{
	private $name;
	private $familyname;
	private $phone;
	private $mobile;	

}