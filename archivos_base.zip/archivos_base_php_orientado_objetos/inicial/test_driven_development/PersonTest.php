<?php
require_once('Person.php');
class PersonTest extends PHPUnit_Framework_TestCase
{

    public function testPersonConstruct()
    {
        
    }

    

}
