<?php

class MyClass
{

	public function greet()
	{
		echo 'Hola hola';
	}

}
