<?php

class Config
{
	const ENVIRONMENT = 'testing';
}